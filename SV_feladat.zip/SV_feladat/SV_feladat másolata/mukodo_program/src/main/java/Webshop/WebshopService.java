package Webshop;

import modells.Customer;
import modells.Payment;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;

public class WebshopService
{
    private List<Customer> customers = new ArrayList<>();
    private List<Payment> payments = new ArrayList<>();

    public void loadCustomers(String filePath)
    {
        try (BufferedReader br = Files.newBufferedReader(Paths.get(filePath)))
        {
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] values = line.split(",");
                if (values.length != 4)
                {
                    logError("Invalid customer record: " + line);
                    continue;
                }
                customers.add(new Customer(values[0], values[1], values[2], values[3]));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void loadPayments(String filePath)
    {
        try (BufferedReader br = Files.newBufferedReader(Paths.get(filePath)))
        {
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] values = line.split(",");
                if (values.length != 7) {
                    logError("Invalid payment record: " + line);
                    continue;
                }
                try
                {
                    double amount = Double.parseDouble(values[3]);
                    LocalDate paymentDate = LocalDate.parse(values[6]);
                    payments.add(new Payment(values[0], values[1], values[2], amount, values[4], values[5], paymentDate));
                }
                catch (NumberFormatException | DateTimeParseException e)
                {
                    logError("Invalid payment record: " + line);
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void logError(String message)
    {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get("application.log"), StandardOpenOption.CREATE, StandardOpenOption.APPEND))
        {
            bw.write(message);
            bw.newLine();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    //-------------------------------------------


    public void generateCustomerReport(String filePath)
    {
        Map<String, Double> customerTotal = new HashMap<>();
        for (Payment payment : payments)
        {
            String customerId = payment.getCustomerId();
            customerTotal.put(customerId, customerTotal.getOrDefault(customerId, 0.0) + payment.getAmount());
        }

        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filePath)))
        {
            for (Customer customer : customers)
            {
                double total = customerTotal.getOrDefault(customer.getCustomerId(), 0.0);
                bw.write(customer.getName() + "," + customer.getAddress() + "," + total);
                bw.newLine();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void generateWebshopReport(String filePath)
    {
        Map<String, Double> cardPayments = new HashMap<>();
        Map<String, Double> transferPayments = new HashMap<>();
        for (Payment payment : payments)
        {
            String webshopId = payment.getWebshopId();
            if ("card".equals(payment.getPaymentMethod()))
            {
                cardPayments.put(webshopId, cardPayments.getOrDefault(webshopId, 0.0) + payment.getAmount());
            }
            else if ("transfer".equals(payment.getPaymentMethod()))
            {
                transferPayments.put(webshopId, transferPayments.getOrDefault(webshopId, 0.0) + payment.getAmount());
            }
        }

        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filePath)))
        {
            for (String webshopId : cardPayments.keySet())
            {
                double cardTotal = cardPayments.getOrDefault(webshopId, 0.0);
                double transferTotal = transferPayments.getOrDefault(webshopId, 0.0);
                bw.write(webshopId + "," + cardTotal + "," + transferTotal);
                bw.newLine();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    //-------------------------------------------
    public void generateTopCustomersReport(String filePath)
    {
        Map<String, Double> customerTotal = new HashMap<>();
        for (Payment payment : payments)
        {
            String customerId = payment.getCustomerId();
            customerTotal.put(customerId, customerTotal.getOrDefault(customerId, 0.0) + payment.getAmount());
        }

        List<Map.Entry<String, Double>> sortedCustomers = new ArrayList<>(customerTotal.entrySet());
        sortedCustomers.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filePath)))
        {
            for (int i = 0; i < Math.min(2, sortedCustomers.size()); i++)
            {
                String customerId = sortedCustomers.get(i).getKey();
                double total = sortedCustomers.get(i).getValue();
                for (Customer customer : customers)
                {
                    if (customer.getCustomerId().equals(customerId))
                    {
                        bw.write(customer.getName() + "," + customer.getAddress() + "," + total);
                        bw.newLine();
                        break;
                    }
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}