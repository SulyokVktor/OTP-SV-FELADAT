package main;

import Webshop.WebshopService;

public class Main {
    public static void main(String[] args) {
        WebshopService service = new WebshopService();

        String desktopPath = System.getProperty("user.home") + "/Desktop/";


        service.loadCustomers(desktopPath + "customer.csv");
        service.loadPayments(desktopPath + "payments.csv");


        service.generateCustomerReport(desktopPath + "report01.csv");
        service.generateTopCustomersReport(desktopPath + "top.csv");
        service.generateWebshopReport(desktopPath + "report02.csv");
    }
}